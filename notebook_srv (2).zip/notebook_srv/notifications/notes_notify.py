import os
import sys
import asyncio
from apscheduler.schedulers.blocking import BlockingScheduler
from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
from dateutil import parser
from aiogram import Bot
import requests

def get_weekly_notes():
    current_dir = os.path.dirname(__file__)
    relative_path = os.path.join(current_dir, '..', 'users', 'SashaKolibri', 'saved_notes')
    notes_path = os.path.abspath(relative_path)
    sys.path.append(notes_path)

    notes_raw = [str(i) for i in open(f'{notes_path}/notes.txt', mode='r', encoding='utf-8').read().split('\n')]

    dates = []
    dnotes = []
    for note in notes_raw:
        dates.append(note.split('%%%')[0])
        dnotes.append({note.split('%%%')[0]: note.split('%%%')[1]})
    dated_notes = {key: [] for key in set(dates)}
    for date in dated_notes.keys():
        for dnote in dnotes:
            if [key for key in dnote.keys()][0] == date:
                dated_notes[date].append(dnote[date])
            else:
                pass
    week_ago = datetime.now().date() - timedelta(days=7)
    weekly_notes = []
    for date in dated_notes.keys():
        if datetime.strptime(date, '%Y-%m-%d').date() > week_ago:
            for note in dated_notes[date]:
                weekly_notes.append(note)
        else:
            pass
    weekly_notes_str = ''
    for note in weekly_notes:
        weekly_notes_str += f'\n{note}'
    return weekly_notes_str

async def send_analysis():
    chat_id = '1078606712'
    #chat_id = '5358455911'
    model_url = 'https://combox.io/api/bitrix/index.php?'
    model_header = {'Content-Type': 'application/x-www-form-urlencoded'}
    bot = Bot(token='7743624973:AAG_B7wMwlCc_8o1rEwbRhPKSPeqFc0RofI')
    analysis_prompt = 'notes_analysis_prompt.txt'
    notes = get_weekly_notes()
    notes_analysis_prompt = f'{open("notes_analysis_prompt.txt", mode="r", encoding="utf-8").read()}\n{notes}'
    user_message = f'{{"role":"user","content":"Сделай анализ в соответствии с промптом."}}'
    data = f'sys_prompt={notes_analysis_prompt}&messages=[{user_message}]'
    response = requests.post(model_url, data=data, headers=model_header).text
    return await bot.send_message(chat_id, 'Вот анализ ваших заметок за прошедшую неделю:' + '\n' + response, parse_mode='markdown')

def run_my_task():
    asyncio.run(send_analysis())
scheduler = BlockingScheduler(timezone="Asia/Krasnoyarsk")
scheduler.add_job(run_my_task, 'cron', day_of_week='fri', hour=13, minute=0)
print("Планировщик запущен. Ожидаем в 13:00 каждую пятницу")
scheduler.start()