from apscheduler.schedulers.blocking import BlockingScheduler
from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
from dateutil import parser
from aiogram import Bot
import asyncio

SERVICE_ACCOUNT_FILE = 'config_dir/victoria_calendar_creds.json'
SCOPES = ['https://www.googleapis.com/auth/calendar']
CALENDAR_ID = 'moiseeva.aleksan68@gmail.com'


def get_today_events(bot, chat_id, service, timezone='Asia/Krasnoyarsk'):
    tz = ZoneInfo(timezone)
    now = datetime.now(tz)
    start_of_day = datetime.combine(now.date(), time.min, tzinfo=tz).isoformat()
    end_of_day = datetime.combine(now.date(), time.max, tzinfo=tz).isoformat()
    events_result = service.events().list(
        calendarId=CALENDAR_ID,
        timeMin=start_of_day,
        timeMax=end_of_day,
        singleEvents=True,
        orderBy='startTime'
    ).execute()
    events = events_result.get('items', [])
    return events

async def send_notification():
    chat_id = '1078606712'
    bot = Bot(token='7303951384:AAGa9Y33RZx0RcLcYVCblH_73VNVdDWbLJ0')
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    service = build('calendar', 'v3', credentials=creds)
    # Пример использования:
    events = get_today_events(bot, chat_id, service)
    ev = ''
    local_tz = ZoneInfo('Asia/Krasnoyarsk')
    for event in events:
        start = event['start'].get('dateTime', event['start'].get('time'))
        if 'dateTime' in event['start']:
            dt_with_tz = parser.isoparse(event['start']['dateTime'])
            dt_local = dt_with_tz.astimezone(local_tz)
            local_time_only = dt_local.time()
            time_str = local_time_only.strftime("%H:%M")
        elif 'date' in event['start']:
            # события на весь день, без времени
            time_str = 'Весь день'
        else:
            continue  # или логгировать
        ev += f"\n{time_str}: {event.get('summary', 'Без названия')}"
    return await bot.send_message(chat_id, 'События на сегодня:' + ev)

def run_my_task():
    asyncio.run(send_notification())

scheduler = BlockingScheduler(timezone="Asia/Krasnoyarsk")

# Каждый день в 9:00
scheduler.add_job(run_my_task, 'cron', hour=9, minute=0)

print("Планировщик запущен. Ожидаем 9:00 каждый день...")
scheduler.start()

