import os
import logging
import asyncio
import sys
from aiogram import Bot, Dispatcher
from aiogram.types import Message
from dotenv import load_dotenv
from pathlib import Path
from handlers import common, start
from filters.allowed_users import AllowedUsers, NotAllowedUsers

# pip install pipreqs
# pipreqs . --force --ignore __pycache__,.pytest_cache,logs,*.png,*.jpg,*.pdf,*.ogg,*.txt,*.json,*.env,.venv,*.pdf,*.doc*

# pip install --upgrade -r requirements.txt
# Зафиксируйте версии зависимостей после обновления:
# pip freeze > requirements.txt

dotenv_path = Path('config_dir/config.env')
load_dotenv(dotenv_path=dotenv_path)

TOKEN = os.getenv('BOT_TOKEN')

def register_not_allowed_handler(dp: Dispatcher):
    @dp.message(NotAllowedUsers('config_dir/allowed_users.txt'))
    async def not_allowed(msg: Message):
        await msg.answer('Вы не авторизованы, у вас нет прав доступа')

async def main() -> None:

    bot = Bot(token=TOKEN)
    dp = Dispatcher()

    register_not_allowed_handler(dp)

    dp.message.filter(AllowedUsers('config_dir/allowed_users.txt'))

    dp.include_routers( start.router, common.router)

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())