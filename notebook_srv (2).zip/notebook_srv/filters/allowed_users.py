from aiogram.filters import BaseFilter
from aiogram.types import Message

class AllowedUsers(BaseFilter):
    def __init__(self, path: str):
        self.path = path
    async def __call__(self, msg: Message) -> bool:
        if msg.from_user.username in [str(i) for i in open(self.path).read().split('\n')]:
            return True
        else:
            return False

class NotAllowedUsers(BaseFilter):
    def __init__(self, path: str):
        self.path = path
    async def __call__(self, msg: Message) -> bool:
        if msg.from_user.username in [str(i) for i in open(self.path).read().split('\n')]:
            return False
        else:
            return True