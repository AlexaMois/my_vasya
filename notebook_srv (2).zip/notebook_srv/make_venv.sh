﻿#!/usr/bin/env bash
set -euo pipefail

# ---------- helpers ----------
print()  { echo -e "$*"; }
error()  { print "\033[1;31m❌ $*\033[0m"; }
info()   { print "\033[1;34m🔨 $*\033[0m"; }
ok()     { print "\033[1;32m✅ $*\033[0m"; }
warn()   { print "\033[1;33m⚠️  $*\033[0m"; }

# ---------- main ----------
clear
print "\033[1;32mСоздание виртуального окружения в папке .venv\033[0m\n"

# 1. Python 3 itself
if ! command -v python3.12 >/dev/null 2>&1; then
    error "Python 3 не найден. Установите пакет python3."
    exit 1
fi

# 2. venv module -------------------------------------------------
if ! python3.12 -c "import venv" 2>/dev/null; then
    warn "Модуль venv отсутствует. Пробую установить python3.12-venv…"
    if command -v sudo >/dev/null 2>&1; then
        sudo apt-get update -qq
        sudo apt-get install -y python3.12-venv
    else
        error "Не удалось установить пакет (sudo недоступен)."
        exit 1
    fi
    # проверяем ещё раз
    if ! python3.12 -c "import venv" 2>/dev/null; then
        error "python3.12-venv установлен, но модуль venv всё ещё не доступен."
        exit 1
    fi
fi

# 3. .venv already exists?
if [[ -d .venv ]]; then
    warn "Папка .venv уже существует. Удалите её вручную, если нужно."
    exit 0
fi

# 4. Create venv
info "Создаю виртуальное окружение в .venv…"
python3.12 -m venv .venv

# 5. Activate & upgrade pip
source .venv/bin/activate
info "Обновляю pip…"
python3.12 -m pip install --quiet --upgrade pip

# 6. Install requirements if present
if [[ -f requirements.txt ]]; then
    info "Устанавливаю зависимости из requirements.txt…"
    pip install --quiet -r requirements.txt
fi

print ""
ok "Готово! Активируйте окружение:  source .venv/bin/activate"