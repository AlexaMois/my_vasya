import json
from time import sleep
import requests
from requests.exceptions import RequestException
from openai import OpenAI, OpenAIError
from mistralai import Mistral

# pip install mistralai
# pip install openai

def remove_think_tags(response):
    if not response:
        return ""
    if not isinstance(response, str):
        response = str(response)
    start_tag = '<think>'
    end_tag = '</think>'
    start_index = response.find(start_tag)
    if start_index == -1:
        return response
    end_index = response.rfind(end_tag, start_index)
    if end_index == -1:
        return response
    return (response[:start_index] + response[end_index + len(end_tag):]).strip()

def clean_json_response(response):
    start = response.find('{')
    end = response.rfind('}')
    if start != -1 and end != -1 and end >= start:
        return response[start:end + 1]
    return ""

# ======================================================================

class LLM_ComBox:
    def is_server_available(self):
        test_prompt = "Send just symbol '1', that's for test"
        test_message = [{"role": "user", "content": "test"}]

        try:
            response = requests.post(
                f"https://combox.io/api/bitrix/index.php?sys_prompt={test_prompt}",
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                data={'messages': json.dumps(test_message)},
                timeout=45
            )
            if response.status_code == 200 and response.text:
                print("Сервер ComBox LLM доступен")
                return True
            else:
                print("Сервер ComBox LLM возвращает пустой ответ")
                return False
        except:
            print("Сервер ComBox LLM недоступен")
            return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 128000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        url = "https://combox.io/api/bitrix/index.php"

        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        # Формируем сообщения (только пользовательские)
        if history:
            messages = history
        else:
            messages = json.dumps([{"role": "user", "content": prompt}])

        # Подготавливаем данные запроса
        data = {
            'sys_prompt': sys_prompt,
            'messages': messages
        }

        try:
            response = requests.post(
                url,
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                data=data,
                timeout=120
            )
            response.raise_for_status()

            try:
                if response.text:
                    return response.text, round((len(data['sys_prompt'])+len(data['messages']))*0.4), round(len(response.text)*0.4)
                print("Ошибка ComBox LLM: пришёл пустой ответ")
                return None, 0, 0
            except json.JSONDecodeError:
                print("Ошибка для ComBox LLM: не удалось распарсить JSON из ответа")
                return None, 0, 0

        except RequestException as e:
            print(f"Ошибка сети для ComBox LLM: {str(e)}")
            return None, 0, 0
        except Exception as e:
            print(f"Неизвестная ошибка для ComBox LLM: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        url = "https://combox.io/api/bitrix/index.php"

        # Формируем системный промпт на основе требуемого формата ответа
        fields_str = ""
        if answer_format:
            schema = answer_format['json_schema']['schema']
            required = schema.get('required', [])
            properties = schema.get('properties', {})
            fields = []
            for field in required:
                if field in properties:
                    field_type = properties[field].get('type', 'string')
                    fields.append(f"'{field}' ({field_type})")
            fields_str = ', '.join(fields) if fields else ""
        if arg_sys_prompt:
            sys_prompt = f"{str(arg_sys_prompt)}\n\nОтвечай строго в формате JSON с полями: {fields_str}."
        else:
            sys_prompt = f"Отвечай строго в формате JSON с полями: {fields_str}."

        # Формируем сообщения (только пользовательские)
        if history:
            messages = history
        else:
            messages = json.dumps([{"role": "user", "content": prompt}])

        # Подготавливаем данные запроса
        data = {
            'sys_prompt': sys_prompt,
            'messages': messages
        }

        try:
            response = requests.post(
                url,
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                data=data,
                timeout=120
            )
            response.raise_for_status()

            # Парсим ответ
            try:
                if response.text:
                    cleaned = clean_json_response(response.text)
                    return json.loads(cleaned) if cleaned else None, round((len(data['sys_prompt'])+len(data['messages']))*0.4), round(len(response.text)*0.4)
                print("Ошибка ComBox LLM: пришёл пустой ответ")
                return None, 0, 0
            except json.JSONDecodeError:
                print("Ошибка ComBox LLM: не удалось распарсить JSON из ответа")
                return None, 0, 0

        except RequestException as e:
            print(f"Ошибка сети для ComBox LLM: {str(e)}")
            return None, 0, 0
        except Exception as e:
            print(f"Неизвестная ошибка для ComBox LLM: {str(e)}")
            return None, 0, 0

# ======================================================================

class LLM_LM_Studio:
    # MODEL = "qwen3-8b"
    MODEL = "qwen3-0.6b"

    def __init__(self):
        self.client = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")

    def is_server_available(self):
        # Указываем URL локального сервера LM Studio
        url = "http://localhost:1234/v1/models"

        try:
            # Отправляем GET-запрос к серверу
            response = requests.head(url, timeout=5)  # таймаут 5 секунд

            # Проверяем статус ответа
            if response.status_code == 200:
                print("Сервер LM Studio доступен.")
                return True
            else:
                print(f"Сервер LM Studio вернул ошибку с кодом: {response.status_code}")
                return False

        except requests.exceptions.ConnectionError:
            print("Не удалось подключиться к серверу LM Studio. Убедитесь, что он запущен.")
            return False
        except requests.exceptions.Timeout:
            print("Время ожидания ответа от сервера LM Studio истекло.")
            return False
        except Exception as e:
            print(f"Произошла ошибка при проверке сервера LM Studio: {str(e)}")
            return False

    def get_prompt_tokens(self, prompt):
        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1,
                stream=False
            )

            # Получаем ответ от модели
            if not completion.usage:
                print("Пустой ответ от модели LM Studio.")
                return 0
            return completion.usage.prompt_tokens

        except Exception as e:
            error_message = str(e)
            print(f"Ошибка при обращении к LM Studio: {error_message}")

            # Проверяем, содержит ли ошибка информацию о превышении длины контекста
            if "Trying to keep the first" in error_message:
                # Ищем число токенов через регулярное выражение
                match = re.search(r"Trying to keep the first (\d+) tokens", error_message)
                if match:
                    # Возвращаем извлеченное число токенов
                    return int(match.group(1))

            # Если ошибка другого типа или число не найдено, возвращаем 0
            return 0

    def get_max_model_tokens(self):
        return self.max_tokens

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        try:
            sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

            messages = [{"role": "system", "content": sys_prompt}]
            if history:
                messages.extend(json.loads(history))
            else:
                messages.append({"role": "user", "content": prompt})

            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False
            )

            # Получаем ответ от модели
            if not completion.choices:
                print("Пустой ответ от модели LM Studio.")
                return None, 0, 0
            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return response_message, tokens_in, tokens_out

        except Exception as e:
            print(f"Ошибка при обращении к LM Studio: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,  # Убедитесь, что MODEL соответствует имени загруженной модели
                messages=messages,
                temperature=0.7,  # Параметр случайности ответа
                stream=False,  # Отключаем потоковую передачу
                response_format=answer_format
            )

            if not completion.choices:
                print("Пустой ответ от модели LM Studio.")
                return None, 0, 0
            response_message = remove_think_tags(completion.choices[0].message.content)
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except Exception as e:
            print(f"Ошибка при обращении к LM Studio: {str(e)}")
            return "", 0, 0

# ======================================================================

class LLM_Mistral:
    MODEL = "mistral-medium-latest"
    API_KEY = "EIwta8KVTMEqh8PvugJx4HKZYG00JXDj"

    def __init__(self):
        self.client = Mistral(
            api_key=self.API_KEY
        )

    def is_server_available(self):
        try:
            chat_response = self.client.chat.complete(
                model=self.MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": "It's just a test if you online or not. Receive me just number 1",
                    },
                ]
            )
            if chat_response.choices[0].message.content:
                print("Сервер Mistral доступен")
                return True
        except Exception as e:
            print(f"Ошибка доступности сервера Mistral: {str(e)}")
            return False
        return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 131000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.complete(
                model=self.MODEL,
                messages=messages,
            )

            if not completion.choices:
                print("Пустой ответ от модели Mistral.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return response_message.split('\n\n\n\n', 1)[0] if '\n\n\n\n' in response_message else response_message, tokens_in, tokens_out

        except OpenAIError as e:
            print(f"Ошибка Mistral: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.complete(
                model=self.MODEL,
                messages=messages,
                response_format=answer_format
            )

            if not completion.choices:
                print("Пустой ответ от модели Mistral.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except (OpenAIError, json.JSONDecodeError) as e:
            print(f"Ошибка при обработке JSON от Mistral: {str(e)}")
            return None, 0, 0

# ======================================================================

class LLM_Together:
    MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free"
    API_KEY = "45703f1c6dadcef65ff6c6031e3b97ea50b2c0c5c7c63168a537f12948e4d738"  # внутри скобок свой апи ключ отсюда https://openrouter.ai/settings/keys
    BASE_URL = "https://api.together.xyz/v1"

    def __init__(self):
        self.client = OpenAI(
            base_url=self.BASE_URL,
            api_key=self.API_KEY
        )

    def is_server_available(self):
        try:
            chat_response = self.client.chat.completions.create(
                model=self.MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": "It's just a test if you online or not. Receive me just number 1",
                    },
                ]
            )

            if chat_response.choices[0].message.content:
                print("Сервер Together.ai доступен")
                return True
        except Exception as e:
            print(f"Ошибка доступности сервера Together.ai: {str(e)}")
            return False
        return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 128000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False
            )

            if not completion.choices:
                print("Пустой ответ от модели Together.ai.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            # Очистка от лишних символов
            return response_message.split('\n\n\n\n', 1)[0] if '\n\n\n\n' in response_message else response_message, tokens_in, tokens_out

        except OpenAIError as e:
            print(f"Ошибка Together.ai: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False,
                response_format=answer_format
            )

            if not completion.choices:
                print("Пустой ответ от модели Together.ai.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except (OpenAIError, json.JSONDecodeError) as e:
            print(f"Ошибка при обработке JSON от Together.ai: {str(e)}")
            return None, 0, 0

# ======================================================================

class LLM_OperRouter:
    MODEL = "qwen/qwen3-32b-04-28:free"
    API_KEY = "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"  # внутри скобок свой апи ключ отсюда https://openrouter.ai/settings/keys
    BASE_URL = "https://openrouter.ai/api/v1"

    def __init__(self):
        self.client = OpenAI(
            base_url=self.BASE_URL,
            api_key=self.API_KEY
        )

    def is_server_available(self):
        """
        Проверяет доступность сервера OpenRouter через минимальный запрос
        """
        try:
            # Используем короткий таймаут и минимальный запрос
            self.client.models.list(timeout=5)
            print("Сервер OperRouter доступен")
            return True
        except OpenAIError as e:
            print(f"Ошибка доступности сервера OperRouter: {str(e)}")
            return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 40000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False
            )

            if not completion.choices:
                print("Пустой ответ от модели OperRouter.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            # Очистка от лишних символов
            return response_message.split('\n\n\n\n', 1)[0] if '\n\n\n\n' in response_message else response_message, tokens_in, tokens_out

        except OpenAIError as e:
            print(f"Ошибка OperRouter: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False,
                response_format=answer_format
            )

            if not completion.choices:
                print("Пустой ответ от модели OperRouter.")
                return None, 0, 0

            response_message = remove_think_tags(completion.choices[0].message.content)
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except (OpenAIError, json.JSONDecodeError) as e:
            print(f"Ошибка при обработке JSON от OperRouter: {str(e)}")
            return None, 0, 0


# ======================================================================

class LLM_Opper:
    MODEL = "gcp/gemini-2.5-pro-exp-03-25"
    API_KEY = "op-MPHAN8CYWSW43H17NCVG"  # Set directly in code [[1]]
    BASE_URL = "https://api.opper.ai/compat/openai"   # Opper's OpenAI compatibility endpoint

    def __init__(self):
        self.client = OpenAI(
            base_url=self.BASE_URL,
            api_key="-",  # Placeholder (required but not used)
            default_headers={"x-opper-api-key": self.API_KEY}  # Actual auth header [[1]]
        )

    def is_server_available(self):
        try:
            # Minimal request to verify service
            self.client.chat.completions.create(
                model=self.MODEL,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=1
            )
            print("Сервер Opper доступен")
            return True
        except OpenAIError as e:
            print(f"Ошибка доступности сервера Opper: {str(e)}")
            return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 1000000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False
            )

            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return response_message.split('\n\n\n\n', 1)[0] if '\n\n\n\n' in response_message else response_message, tokens_in, tokens_out

        except OpenAIError as e:
            print(f"Opper error: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False,
                response_format=answer_format
            )

            response_message = completion.choices[0].message.content
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except (OpenAIError, json.JSONDecodeError) as e:
            print(f"JSON processing error for Opper: {str(e)}")
            return None, 0, 0


# ======================================================================

class LLM_OpenAI:
    MODEL = "gpt-4.1-mini"
    API_KEY = "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" # для стенограмм и протоколов
    # API_KEY = "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"  # тендеры
    BASE_URL = "https://api.openai.com/v1/chat/completions"   # Основной эндпоинт OpenAI [[1]]

    def __init__(self):
        self.client = OpenAI(api_key=self.API_KEY)

    def is_server_available(self):
        """
        Проверяет доступность сервера OpenAI через запрос к списку моделей.
        Возвращает True, если сервер доступен, иначе False.
        """
        try:
            # Используем короткий таймаут для экономии времени и трафика
            self.client.models.list(timeout=5)
            print("Сервер OpenAI доступен")
            return True
        except OpenAIError as e:
            print(f"Ошибка доступности сервера OpenAI: {str(e)}")
            return False

    def get_prompt_tokens(self, prompt):
        return int(len(prompt)*0.4)

    def get_max_model_tokens(self):
        return 1000000

    def ask(self, prompt, arg_sys_prompt=None, history=None):
        sys_prompt = str(arg_sys_prompt) or "Ответь на запрос в лаконичной форме."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False
            )

            response_message = remove_think_tags(completion.choices[0].message.content)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            # Очистка от лишних символов
            return response_message.split('\n\n\n\n', 1)[0] if '\n\n\n\n' in response_message else response_message, tokens_in, tokens_out

        except OpenAIError as e:
            print(f"Ошибка OpenAI: {str(e)}")
            return None, 0, 0

    def ask_json(self, prompt, answer_format, arg_sys_prompt=None, history=None):
        if arg_sys_prompt:
            sys_prompt = str(arg_sys_prompt) + "\n\nОтвечай строго в формате JSON."
        else:
            sys_prompt = "Отвечай строго в формате JSON."

        messages = [{"role": "system", "content": sys_prompt}]
        if history:
            messages.extend(json.loads(history))
        else:
            messages.append({"role": "user", "content": prompt})

        try:
            completion = self.client.chat.completions.create(
                model=self.MODEL,
                messages=messages,
                temperature=0.7,
                stream=False,
                response_format=answer_format  # Прямая передача формата
            )

            response_message = completion.choices[0].message.content
            cleaned = clean_json_response(response_message)
            tokens_in = completion.usage.prompt_tokens
            tokens_out = completion.usage.completion_tokens
            return json.loads(cleaned) if cleaned else None, tokens_in, tokens_out

        except (OpenAIError, json.JSONDecodeError) as e:
            print(f"Ошибка при обработке JSON для OpenAI: {str(e)}")
            return None, 0, 0

# ======================================================================


class LLM_union:
    def __init__(self, models):
        self.models = models
        self.current_model_index = 0

    def is_server_available(self):
        for i in range(len(self.models)):
            idx = (self.current_model_index + i) % len(self.models)
            model = self.models[idx]
            if model.is_server_available():
                self.current_model_index = idx
                sleep(1)
                return True
        return False

    def get_prompt_tokens(self, prompt):
        for i in range(len(self.models)):
            idx = (self.current_model_index + i) % len(self.models)
            model = self.models[idx]
            toekns = model.get_prompt_tokens(prompt)
            sleep(1)
            return toekns
        return False

    def get_max_model_tokens(self):
        for i in range(len(self.models)):
            idx = (self.current_model_index + i) % len(self.models)
            model = self.models[idx]
            toekns = model.get_max_model_tokens()
            sleep(1)
            return toekns
        return False

    def ask(self, prompt, sys_prompt=None, history=None):
        for i in range(len(self.models)):
            idx = (self.current_model_index + i) % len(self.models)
            model = self.models[idx]
            result, tok_in, tok_out = model.ask(prompt, sys_prompt, history)
            if result is not None:
                self.current_model_index = idx
                sleep(1)
                return result, tok_in, tok_out
        return None, 0, 0

    def ask_json(self, prompt, answer_format, sys_prompt=None, history=None):
        for i in range(len(self.models)):
            idx = (self.current_model_index + i) % len(self.models)
            model = self.models[idx]
            result, tok_in, tok_out = model.ask_json(prompt, answer_format, sys_prompt, history)
            if result is not None:
                self.current_model_index = idx
                sleep(1)
                return result, tok_in, tok_out
        return None, 0, 0


models = [LLM_ComBox(), LLM_OperRouter(), LLM_Mistral(), LLM_Together()]
llm = LLM_union(models)

# if True:
#     card_data_prompt = f'''Ты ИИ-ассистент агентства НейроРешение. Извлеки данные с визитки клиента в JSON-объект по шаблону:
#     {{
#         "date": "2025-01-01",
#         "name": "ФИО",
#         "organization": "организация",
#         "address": "адрес",
#         "phones": "номера телефонов",
#         "email": "email"
#     }}
#
#     Правила:
#     - Ответ только в виде JSON-объекта, без пояснений
#     - Дублирующиеся данные указывай 1 раз
#     - Пропущенные поля заменяй на ""
#     - Игнорируй данные ComBox Technology
#     - Телефоны возвращай в одну строку, разделяя их запятой
#
#     Исходные данные о клиенте: Петр Феодосович, 8-495-44-33-222, ttwerk@gmail.com'''
#
#     print(llm.ask_json(card_data_prompt, None))

