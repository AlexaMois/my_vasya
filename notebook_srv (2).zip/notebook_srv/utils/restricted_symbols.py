import re


def restricted_symbols(text):
    cleaned_text = re.sub(r'[^\w\s.,!?-]', '', text)
    return cleaned_text