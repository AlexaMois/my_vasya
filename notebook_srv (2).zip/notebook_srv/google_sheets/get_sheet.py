import gspread
from google.oauth2.service_account import Credentials
from collections import Counter
import pandas as pd

GOOGLE_SHEET_ID = '1wv1V58jnDEQsxw8XJMMkKKiPFEv0YYDZ_419wfsIBsw'

GOOGLE_SHEET_CONTACTS_ID = '1evH4GoWMNwrjmjN5VWade281rH2g5dDGEMEaLUdF85U'

creds = Credentials.from_service_account_file('config_dir/victoria_calendar_creds.json', 
                                            scopes=['https://spreadsheets.google.com/feeds', 
                                                   'https://www.googleapis.com/auth/drive',
                                                   'https://www.googleapis.com/auth/spreadsheets'])
client = gspread.authorize(creds)

def get_worksheet_names(table_id=None):
    """Получает имена всех листов в таблице по ID"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_ID
            
        # Пытаемся открыть по ID, если не получается - по имени
        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)
            
        worksheets = table.worksheets()
        return [ws.title for ws in worksheets]
    except Exception as e:
        print(f"Ошибка при получении листов таблицы: {e}")
        return []

def get_sheet_data(table_id=None, worksheet_name="КОНТАКТЫ/ЛИДЫ"):
    """Получает данные с указанного листа таблицы"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_ID
            
        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)
            
        sheet_by_name = table.worksheet(worksheet_name)
        data = sheet_by_name.get_all_values()
        
        if not data:
            return f"Лист '{worksheet_name}' пустой."
            
        headers = data[0]
        counts = Counter()
        unique_headers = []
        for h in headers:
            counts[h] += 1
            if counts[h] > 1:
                unique_headers.append(f'{h}_{counts[h]}')
            else:
                unique_headers.append(h)
                
        df = pd.DataFrame(data[1:], columns=unique_headers)
        return f'Таблица: {worksheet_name}\n{df.to_string()}'
    except gspread.exceptions.WorksheetNotFound:
        return f"Лист '{worksheet_name}' не найден в таблице."
    except Exception as e:
        print(f"Ошибка при получении данных таблицы: {e}")
        return f"Ошибка при получении данных: {str(e)}"

def append_card_data(table_id, row_list, worksheet_name='КОНТАКТЫ/ЛИДЫ'):
    """Добавляет данные на указанный лист таблицы"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_CONTACTS_ID
        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)
            
        # Проверяем существование листа
        try:
            sheet = table.worksheet(worksheet_name)
        except gspread.exceptions.WorksheetNotFound:
            sheet = table.add_worksheet(title=worksheet_name, rows="100", cols="20")
            headers = [
                "Дата добавления", "Имя клиента", "Организация", "Локация", "Телефон(ы)", "Электронная почта",
                "Никнейм в Телеграме", "Предпочит. канал связи", "Соцсети и проекты", "Запрос клиента",
                "Этапы взаимодействия", "Ответ клиента", "Ответ агентства", "Ключевые потребности клиента",
                "Статус взаимодействия", "Дальнейшие действия", "Персональная заметка", "Дата последнего контакта"
            ]
            sheet.append_row(headers)
        sheet.append_row(row_list)
        return True
    except Exception as e:
        print(f"Ошибка при добавлении данных в таблицу: {e}")
        return False

def get_notes_data(table_id=None, worksheet_name='Заметки'):
    """Получает данные заметок из Google-таблицы в виде списка словарей"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_ID

        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)

        # Проверяем, существует ли лист "Заметки", если нет - создаем
        try:
            sheet = table.worksheet(worksheet_name)
        except gspread.exceptions.WorksheetNotFound:
            sheet = table.add_worksheet(title=worksheet_name, rows="100", cols="20")
            # Добавляем заголовки, если лист новый
            sheet.append_row(["Дата", "Текст заметки"])
            return []
        
        # Получаем данные как список словарей
        notes_found = sheet.get_all_records()
        return notes_found
    except Exception as e:
        print(f"Ошибка при получении заметок: {e}")
        return []

def add_note_to_sheet(table_id, note_date, note_text, worksheet_name='Заметки'):
    """Добавляет новую заметку в таблицу"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_ID

        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)

        # Проверяем существование листа "Заметки"
        try:
            sheet = table.worksheet(worksheet_name)
        except gspread.exceptions.WorksheetNotFound:
            sheet = table.add_worksheet(title=worksheet_name, rows="100", cols="20")
            sheet.append_row(["Дата", "Текст заметки"])

        sheet.append_row([note_date, note_text])
        return True
    except Exception as e:
        print(f"Ошибка при добавлении заметки: {e}")
        return False

def delete_note_from_sheet(table_id, index, worksheet_name='Заметки'):
    """Удаляет заметку по индексу (начиная с 0)"""
    try:
        if table_id is None:
            table_id = GOOGLE_SHEET_ID
            
        try:
            table = client.open_by_key(table_id)
        except gspread.exceptions.SpreadsheetNotFound:
            table = client.open(table_id)

        sheet = table.worksheet(worksheet_name)
        
        # Получаем все данные
        all_data = sheet.get_all_values()
        # Удаляем заголовок
        data = all_data[1:]
        
        # Проверяем индекс
        if 0 <= index < len(data):
            # Удаляем строку (индекс + 2, так как нумерация в Google Sheets начинается с 1 и учитываем заголовок)
            sheet.delete_rows(index + 2)
            return True
        return False
    except Exception as e:
        print(f"Ошибка при удалении заметки: {e}")
        return False