from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

def search_kb() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Поиск в заметках', callback_data='find_notes'),
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def return_to_notes() -> InlineKeyboardMarkup:
    kb = [
        [InlineKeyboardButton(text='Вернуться к записи заметок', callback_data='goto_wnotes')],
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def notes_main_menu() -> InlineKeyboardMarkup:
    """Показывается при первом переходе в режим заметок."""
    kb = [
        [InlineKeyboardButton(text="🔍 Найти", callback_data="find_notes")],
        [InlineKeyboardButton(text="🗑 Удалить", callback_data="delete_notes")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def return_to_notes_with_actions() -> InlineKeyboardMarkup:
    """Показывается после поиска/удаления и т.п."""
    kb = [
        [
            InlineKeyboardButton(text="🔍 Найти", callback_data="find_notes"),
            InlineKeyboardButton(text="🗑 Удалить", callback_data="delete_notes"),
        ],
        [InlineKeyboardButton(text="Вернуться к записи заметок", callback_data="goto_wnotes")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def calendar_actions() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Создать ивент', callback_data='create_event'),
            #InlineKeyboardButton(text='Удалить ивент', callback_data='delete_event')
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def no_second_card_photo() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Нет оборота', callback_data='no_card_side_2'),
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def card_get_comment() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Да', callback_data='card_comment_yes'),
            InlineKeyboardButton(text='Нет', callback_data='card_comment_no')
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def lawyer_actions() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Документ', callback_data='lawyer_doc_analysis'),
            InlineKeyboardButton(text='Консультация', callback_data='lawyer_consulting')
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def lawyer_docs_get_to_consulting() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Консультация', callback_data='lawyer_consulting'),
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def lawyer_consulting_get_to_docs() -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton(text='Документы', callback_data='lawyer_doc_analysis'),
        ],
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=kb)
    return keyboard

def get_all_sheets_kb(items: list[str]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for item in items:
        builder.button(text=item, callback_data=f"{item}")
    builder.adjust(3)
    return builder.as_markup()

