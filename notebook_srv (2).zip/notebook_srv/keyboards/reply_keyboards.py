from aiogram.types import ReplyKeyboardMarkup
from aiogram.utils.keyboard import KeyboardButton

def main_kb() -> ReplyKeyboardMarkup:
    kb = [
        [
            KeyboardButton(text='~Календарь'),
            KeyboardButton(text='~Гугл-таблица')
        ],
        [
            KeyboardButton(text='~Заметки'),
            KeyboardButton(text='~Юрист')
        ],
        [
            KeyboardButton(text='~Визитка')
        ]
    ]
    keyboard = ReplyKeyboardMarkup(keyboard=kb,
                                   resize_keyboard=True,
                                   )
    return keyboard