from aiogram.fsm.state import StatesGroup, State

class Notes(StatesGroup):
    notes = State()
    find_notes = State()
    delete_notes = State()

class Calendar(StatesGroup):
    calendar_input = State()
    create_event = State()

class GoogleSheets(StatesGroup):
    choosing_sheet = State()
    what_to_find = State()

class LawyerAssistant(StatesGroup):
    lawyer = State()
    lawyer_docs = State()
    lawyer_consulting = State()

class ContactCardInput(StatesGroup):
    card_step_1 = State()
    card_step_2 = State()
    get_comments = State()