import asyncio
import os
import re
import time
import ast
import base64
import requests
from docx import Document
from pypdf import PdfReader
from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
import md2tgmd
import json

from states.states import Notes, Calendar, GoogleSheets, LawyerAssistant, ContactCardInput
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
from utils.restricted_symbols import restricted_symbols
from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import datetime
from google_sheets.get_sheet import get_sheet_data, append_card_data, get_worksheet_names, get_notes_data, add_note_to_sheet, delete_note_from_sheet, GOOGLE_SHEET_ID, GOOGLE_SHEET_CONTACTS_ID
from keyboards.inline_keyboards import search_kb, calendar_actions, no_second_card_photo, lawyer_actions, notes_main_menu, return_to_notes, return_to_notes_with_actions, get_all_sheets_kb, card_get_comment, lawyer_docs_get_to_consulting, lawyer_consulting_get_to_docs

from llm_choise import llm

router = Router()

dotenv_path = Path('config_dir/config.env')
load_dotenv(dotenv_path=dotenv_path)

GOOGLE_SERVICE_ACCOUNT_FILE_PATH = 'config_dir/victoria_calendar_creds.json'
GOOGLE_SCOPES = ['https://www.googleapis.com/auth/calendar']
CALENDAR_ID = os.getenv('CALENDAR_ID')
TIME_ZONE = os.getenv('TIME_ZONE')
OPENAI_TOKEN = os.getenv('OPENAI_TOKEN')
openai_client = OpenAI(api_key=OPENAI_TOKEN)
LAWYER_ID = os.getenv('LAWYER_ID')

# common.py  (top-level)
MODE_SWITCHES = {
    '~Календарь': (Calendar.calendar_input,
                   "Что хотите сделать в календаре?",
                   calendar_actions,
                   "Вы уже в режиме календаря!"),
    '~Гугл-таблица': (GoogleSheets.choosing_sheet,
                      "Выберите нужный лист в таблице.",
                      lambda: get_all_sheets_kb(get_worksheet_names(GOOGLE_SHEET_ID)),
                      "Вы уже в режиме таблицы!"),
    '~Юрист':   (LawyerAssistant.lawyer,
                 "Что хотите от юриста?",
                 lawyer_actions,
                 "Юрист уже с вами."),
    '~Заметки': (Notes.notes,
                 "Теперь вы в режиме записи новых заметок.\nДля изменения режима нажмите соответсвующую кнопку.",
                 notes_main_menu,
                 "Вы уже в режиме заметок!"),
    '~Визитка': (ContactCardInput.card_step_1,
                 "Отправьте фотографию визитки.",
                 None,
                 "Вы уже в режиме визиток."),
}

async def send_or_edit(obj, text: str, **kwargs):
    """
    obj – Message или CallbackQuery.
    Отправляет новое сообщение, если это входящее сообщение,
    либо редактирует, если это CallbackQuery или исходящее сообщение.
    """
    if isinstance(obj, CallbackQuery):
        await obj.message.edit_text(text, **kwargs)
    else:  # Message (входящее от пользователя)
        await obj.answer(text, **kwargs)

async def try_mode_switch(obj, state: FSMContext) -> bool:
    text = obj.text if isinstance(obj, Message) else obj.data
    if text not in MODE_SWITCHES:
        return False

    new_state, answer_text, kb_factory, already_msg = MODE_SWITCHES[text]
    current_state = await state.get_state()
    target_state_str = str(new_state)

    kb = kb_factory() if kb_factory else None

    if current_state == target_state_str:
        await send_or_edit(obj, already_msg, reply_markup=kb)
    else:
        await state.clear()
        await state.set_state(new_state)
        await send_or_edit(obj, answer_text, reply_markup=kb)
    return True

async def transcribe_voice(voice_file_id: str, bot) -> str:
    dir_path = 'buff_voice/'
    await bot.download(file=voice_file_id, destination=f'{dir_path}{voice_file_id}.ogg')
    with open(f'{dir_path}{voice_file_id}.ogg', 'rb') as f:
        transcript = openai_client.audio.transcriptions.create(
            model='whisper-1',
            file=f,
            response_format='text',
            prompt='Тебе поступит голосовое сообщение на русском языке (ru), сделай его стенограмму в виде текста.'
        )
    os.remove(f'{dir_path}{voice_file_id}.ogg')
    return transcript

@router.message(Notes.notes)
async def write_notes(msg: Message, state: FSMContext):
    try:
        if not msg.voice:
            message = msg.text
            if await try_mode_switch(msg, state):
                return None
            else:
                pass
        else:
            message = await transcribe_voice(msg.voice.file_id, msg.bot)

        # Сохраняем заметку в Google-таблицу
        note_date = msg.date.date().isoformat()
        note_text = message.replace("\n", " ")
        
        # Добавляем заметку в таблицу на лист "Заметки"
        if add_note_to_sheet(GOOGLE_SHEET_ID, note_date, note_text):
            await asyncio.sleep(1)
            await msg.answer('Записал заметку.', reply_markup=search_kb())
        else:
            await msg.answer('Не удалось сохранить заметку. Попробуйте позже.')
    except Exception as e:
        return await msg.answer(f'Ошибка в заметках: {e}. Пожалуйста, обратитесь к администратору.')

@router.callback_query(Notes.notes, F.data == 'find_notes')
async def weekly_analysis_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Notes.find_notes)
    await asyncio.sleep(1)
    await callback.message.edit_text('Конечно! Какую заметку (заметки) мне для вас найти?', reply_markup=return_to_notes_with_actions())

@router.callback_query(Notes.find_notes, F.data == 'goto_wnotes')
async def weekly_analysis_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Notes.notes)
    await asyncio.sleep(1)
    await callback.message.edit_text('Вы снова в режиме записи заметок.')

@router.callback_query(Notes.notes, F.data == "delete_notes")          # NEW
async def delete_notes_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(Notes.delete_notes)
    await asyncio.sleep(1)
    await callback.message.edit_text(
        "**Удаление заметок**\n"
        "Отправьте номер строки (по порядку сверху вниз), которую хотите удалить, либо часть текста для поиска и удаления.",
        parse_mode="MarkdownV2",
        reply_markup=return_to_notes()
    )

@router.callback_query(GoogleSheets.choosing_sheet, F.data)
async def choosing_table(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GoogleSheets.what_to_find)
    await state.update_data(curr_sheet=callback.data)
    await asyncio.sleep(1)
    await callback.message.edit_text('Хорошо, что вас интересует?')

@router.message(GoogleSheets.choosing_sheet, F.text)
async def choosing_cancellation(msg: Message, state: FSMContext):
    if await try_mode_switch(msg, state):
        return
    else:
        pass

@router.callback_query(Calendar.calendar_input, F.data == 'create_event')
async def create_event_input(callback: CallbackQuery, state: FSMContext):
    await asyncio.sleep(1)
    await callback.message.edit_text('Пожалуйста, укажите название, описание, время начала и время окончания ивента')
    await state.set_state(Calendar.create_event)

@router.message(Calendar.calendar_input)
async def lawyer_cancellation(msg: Message, state: FSMContext):
    await try_mode_switch(msg, state)

@router.callback_query(LawyerAssistant.lawyer, F.data == 'lawyer_doc_analysis')
async def create_event_input(callback: CallbackQuery, state: FSMContext):
    await state.set_state(LawyerAssistant.lawyer_docs)
    await asyncio.sleep(1)
    return await callback.message.edit_text('Конечно! Пожалуйста, загрузите документ, с которым мы будем работать.')

@router.callback_query(LawyerAssistant.lawyer, F.data == 'lawyer_consulting')
async def create_event_input(callback: CallbackQuery, state: FSMContext):
    await state.set_state(LawyerAssistant.lawyer_consulting)
    await asyncio.sleep(1)
    return await callback.message.edit_text('Хорошо. Что вас интересует?')

@router.message(LawyerAssistant.lawyer, F.text)
async def lawyer_cancellation(msg: Message, state: FSMContext):
    await try_mode_switch(msg, state)

@router.message(Calendar.calendar_input, F.text)
async def calendar_quit(msg: Message, state: FSMContext):
    try:
        if await try_mode_switch(msg, state):
            return
        else:
            pass
    except Exception as e:
        return await msg.answer(f'Ошибка в календаре: {e}. Пожалуйста, попробуйте еще раз.')

@router.message(Notes.find_notes)
async def search_notes_mode(msg: Message, state: FSMContext):
    try:
        if not msg.voice:
            if await try_mode_switch(msg, state):
                return
            else:
                reply = await msg.answer('Думаю...')
                user_message = msg.text
                user_message = restricted_symbols(user_message.replace('\n', ''))
                pass
        else:
            reply = await msg.answer('Думаю...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))

        context_path = 'users/' + msg.from_user.username + '/llm_context/context.txt'
        history_path = context_path

        # Получаем данные заметок из Google-таблицы
        notes = get_notes_data()
        
        # Форматируем данные для поиска
        notes_text = ''
        for i, note in enumerate(notes):
            note_date = note.get('Дата', '')
            note_text = note.get('Текст заметки', '')
            notes_text += f'\nДата: {note_date}, Заметка: {note_text}'
        
        notes_search_prompt = f'{open("texts_and_prompts/notes_search_prompt.txt", mode="r", encoding="utf-8").read()}\n{notes_text}'

        history_raw = [str(i) for i in open(history_path, 'r', encoding='utf-8').read().split('\n')]
        if len(history_raw) >= 80:
            history_raw = history_raw[-80:]
        history_split = []
        for dialogue_round in history_raw:
            history_split.append({dialogue_round.split('%%%')[0]: dialogue_round.split('%%%')[1]})
        history = ''
        for dialogue_round in history_split:
            history += f'{{"role":"user","content":"{restricted_symbols(str([key for key in dialogue_round.keys()]).lstrip("['").rstrip("']"))}"}},{{"role":"assistant","content":"{restricted_symbols(str([value for value in dialogue_round.values()]).lstrip("['").rstrip("']"))}"}},'
        last_message = f'{{"role":"user","content":"{user_message}"}}'
        response, _in, _out = llm.ask(None, notes_search_prompt, f'[{history}{last_message}]')
        if not response or 'Warning' in response:
            os.remove('users/' + msg.from_user.username + '/llm_context/context.txt')
            await reply.edit_text('Возникла ошибка языковой модели. Придется начать нашу беседу заново.')
        else:
            response = md2tgmd.escape(response)
            history_file = open(history_path, 'a', encoding='utf-8')
            history_file.write('\n{}%%%{}'.format(user_message,
                                                  restricted_symbols(
                                                      response.replace('\n', ' '))
                                                  )
                               )
            history_file.close()
            await asyncio.sleep(1)
            await reply.edit_text(response, parse_mode='MarkdownV2', reply_markup=return_to_notes_with_actions())
    except Exception as e:
        await state.set_state(Notes.notes)
        return await msg.answer(f'Ошибка в режиме заметок: {e}. Пожалуйста, попробуйте еще раз.')


@router.message(Notes.delete_notes)
async def delete_notes_confirm(msg: Message, state: FSMContext):
    try:
        if not msg.voice:
            if await try_mode_switch(msg, state):
                return
            else:
                user_message = msg.text
                user_message = restricted_symbols(user_message.replace('\n', ''))
                pass
        else:
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))

        # Получаем данные заметок из Google-таблицы
        notes = get_notes_data()
        
        # Проверяем, есть ли заметки
        if not notes:
            await msg.answer("У вас пока нет заметок.")
            return

        # Попытка удалить по номеру строки
        if user_message.isdigit():
            idx = int(user_message) - 1
            if 0 <= idx < len(notes):
                removed = notes[idx]
                if delete_note_from_sheet(GOOGLE_SHEET_ID, idx):
                    await msg.answer(f"✅ Заметка удалена:\nДата: {removed.get('Дата', '')}\nЗаметка: {removed.get('Текст заметки', '')}", 
                                    reply_markup=return_to_notes_with_actions())
                else:
                    await msg.answer("❌ Не удалось удалить заметку. Попробуйте позже.")
            else:
                await msg.answer("❌ Неверный номер строки.")
        else:
            # Удаление по совпадению текста
            candidates = [note for note in notes if user_message.lower() in note.get('Текст заметки', '').lower()]
            if not candidates:
                await msg.answer("❌ Совпадений не найдено.")
            elif len(candidates) == 1:
                idx = notes.index(candidates[0])
                if delete_note_from_sheet(GOOGLE_SHEET_ID, idx):
                    await msg.answer(f"✅ Удалена заметка:\nДата: {candidates[0].get('Дата', '')}\nЗаметка: {candidates[0].get('Текст заметки', '')}", 
                                    reply_markup=return_to_notes_with_actions())
                else:
                    await msg.answer("❌ Не удалось удалить заметку. Попробуйте позже.")
            else:
                text = "Найдено несколько совпадений. Уточните запрос:\n" + "\n".join(
                    f"{i+1}. Дата: {note.get('Дата', '')}, Заметка: {note.get('Текст заметки', '')[:50]}..." 
                    for i, note in enumerate(candidates)
                )
                await msg.answer(text)
    except Exception as e:
        await msg.answer(f"Ошибка при удалении: {e}. Попробуйте еще раз.")


@router.message(Calendar.create_event)
async def create_event_confirm(msg: Message, state: FSMContext):
    try:
        if not msg.voice:
            if await try_mode_switch(msg, state):
                return
            else:
                reply = await msg.answer('Создаю ивент...')
                user_message = msg.text
                user_message = restricted_symbols(user_message.replace('\n', ''))
        else:
            reply = await msg.answer('Создаю ивент...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))

        ce_prompt = open("texts_and_prompts/create_event_prompt.txt", mode="r", encoding="utf-8").read() + f" {msg.date}"
        response_json, _in, _out = llm.ask_json(user_message, None, ce_prompt)

        if not response_json:
            raise ValueError(f"Некорректный ответ от LLM модели")

        try:
            start_time = datetime.strptime(response_json['start_time'], '%Y-%m-%d %H:%M:%S')
            end_time = datetime.strptime(response_json['end_time'], '%Y-%m-%d %H:%M:%S')
        except KeyError as e:
            raise ValueError(f"Отсутствует ключ даты в ответе LLM модели: {e}")

        creds = service_account.Credentials.from_service_account_file(GOOGLE_SERVICE_ACCOUNT_FILE_PATH, scopes=GOOGLE_SCOPES)

        service = build('calendar', 'v3', credentials=creds)

        event = {
            'summary': response_json['title'],
            'description': response_json['comment'],
            'start': {
                'dateTime': start_time.isoformat(),
                'timeZone': TIME_ZONE,
            },
            'end': {
                'dateTime': end_time.isoformat(),
                'timeZone': TIME_ZONE,
            },
        }
        created_event = service.events().insert(calendarId=CALENDAR_ID, body=event).execute()
        print(f"Событие создано: {created_event.get('htmlLink')}")
        await asyncio.sleep(1)
        await reply.edit_text(
            f'Событие занесено в календарь!\n\n'
            f'Задача: {response_json["title"]}\n'
            f'Описание: {response_json["comment"]}\n'
            f'Время начала: {response_json["start_time"]}\n'
            f'Время окончания: {response_json["end_time"]}'
        )
        await state.set_state(Notes.notes)
    except Exception as e:
        await state.set_state(Notes.notes)
        return await msg.answer(f'Ошибка при подтверждении события: {e}. Пожалуйста, попробуйте еще раз.')

@router.callback_query(GoogleSheets.what_to_find, F.data)
async def choosing_table(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GoogleSheets.what_to_find)
    await state.update_data(curr_sheet=callback.data)
    await asyncio.sleep(1)
    await callback.message.answer('Хорошо. Что вас интересует?')

@router.message(GoogleSheets.what_to_find)
async def what_to_find(msg: Message, state: FSMContext):
    try:
        if not msg.voice:
            if await try_mode_switch(msg, state):
                return
            else:
                reply = await msg.answer('Думаю...')
                user_message = msg.text
                user_message = restricted_symbols(user_message.replace('\n', ''))
                pass
        else:
            reply = await msg.answer('Думаю...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))
        state_data = await state.get_data()
        sheet_name = state_data['curr_sheet']
        sheet_data = get_sheet_data(GOOGLE_SHEET_ID, sheet_name)
        context_path = 'users/' + msg.from_user.username + '/llm_context/context.txt'
        history_path = context_path
        gs_analysis_prompt = f'{open("texts_and_prompts/gs_sheets_prompt.txt", mode="r", encoding="utf-8").read()}\n\n{sheet_data}'
        history_raw = [str(i) for i in open(history_path, 'r', encoding='utf-8').read().split('\n')]
        if len(history_raw) >= 80:
            history_raw = history_raw[-80:]
        history_split = []
        for dialogue_round in history_raw:
            history_split.append({dialogue_round.split('%%%')[0]: dialogue_round.split('%%%')[1]})
        history = ''
        for dialogue_round in history_split:
            history += f'{{"role":"user","content":"{restricted_symbols(str([key for key in dialogue_round.keys()]).lstrip("['").rstrip("']"))}"}},{{"role":"assistant","content":"{restricted_symbols(str([value for value in dialogue_round.values()]).lstrip("['").rstrip("']"))}"}},'
        last_message = f'{{"role":"user","content":"{user_message}"}}'
        response, _in, _out = llm.ask(None, gs_analysis_prompt, f'[{history}{last_message}]')
        if not response or 'Warning' in response:
            os.remove('users/' + msg.from_user.username + '/llm_context/context.txt')
            await reply.edit_text('Возникла ошибка языковой модели. Придется начать нашу беседу заново.')
        else:
            response = md2tgmd.escape(response)
            history_file = open(history_path, 'a', encoding='utf-8')
            history_file.write('\n{}%%%{}'.format(user_message,
                                                  restricted_symbols(
                                                      response.replace('\n', ' '))
                                                  )
                               )
            history_file.close()
            await reply.edit_text(response, parse_mode='MarkdownV2', reply_markup=get_all_sheets_kb(get_worksheet_names(GOOGLE_SHEET_ID)))
    except Exception as e:
        return await msg.answer(f'Ошибка при поиске: {e}. Попробуйте еще раз.')

def extract_text_from_pdf(file_path):
    text = ''
    with open(file_path, 'rb') as file:
        reader = PdfReader(file)
        for page in reader.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(file_path):
    doc = Document(file_path)
    text = ''
    for para in doc.paragraphs:
        text += para.text + '\n'
    return text

def save_text_to_docx(text, output_path):
    doc = Document()
    doc.add_paragraph(text)
    doc.save(output_path)

@router.callback_query(LawyerAssistant.lawyer_consulting, F.data == 'lawyer_doc_analysis')
async def create_event_input(callback: CallbackQuery, state: FSMContext):
    await state.set_state(LawyerAssistant.lawyer_docs)
    await asyncio.sleep(1)
    return await callback.message.answer('Конечно! Загрузите документ, с которым мы будем работать.')

@router.callback_query(LawyerAssistant.lawyer_docs, F.data == 'lawyer_consulting')
async def create_event_input(callback: CallbackQuery, state: FSMContext):
    await state.set_state(LawyerAssistant.lawyer_consulting)
    await asyncio.sleep(1)
    return await callback.message.answer('Хорошо. Что вас интересует?')

@router.message(LawyerAssistant.lawyer_docs)
async def lawyer_docs(msg: Message, state: FSMContext):
    try:
        dir_path = f'users/{msg.from_user.username}/lawyer_sdocs/'
        os.makedirs(dir_path, exist_ok=True)

        user_message = ''
        doc_id = ''
        new_thread = False

        if msg.document:
            reply = await msg.answer('Загружаю документ...')
            doc_file_id = msg.document.file_id
            doc_file_name = msg.document.file_name
            file_path = os.path.join(dir_path, doc_file_name)

            await msg.bot.download(file=doc_file_id, destination=file_path)

            if doc_file_name.lower().endswith(('.pdf', '.docx')):
                if doc_file_name.lower().endswith('.docx'):
                    doc_text = extract_text_from_docx(file_path)
                    open(dir_path + 'current_doc_text.txt', mode='w', encoding='utf-8').write(doc_text)
                elif doc_file_name.lower().endswith('.pdf'):
                    doc_text = extract_text_from_pdf(file_path)
                    open(dir_path + 'current_doc_text.txt', mode='w', encoding='utf-8').write(doc_text)

                with open(f'{dir_path}current_doc_id.txt', 'w', encoding='utf-8') as f:
                    f.write(doc_id)

                thread_id = openai_client.beta.threads.create().id
                with open(f'users/{msg.from_user.username}/lawyer_threads/doc_thread_id.txt', 'w', encoding='utf-8') as f:
                    f.write(thread_id)

                user_message = msg.caption if msg.caption else 'Расскажите, что представляет собой этот документ.'
                new_thread = True
            else:
                return await reply.edit_text('Неподдерживаемый формат документа. Пожалуйста, выберите PDF или DOCX.')

        elif msg.text:
            if await try_mode_switch(msg, state):
                return
            else:
                reply = await msg.answer('Думаю...')
                user_message = msg.text
                user_message = restricted_symbols(user_message.replace('\n', ''))
                thread_file_path = f'users/{msg.from_user.username}/lawyer_threads/doc_thread_id.txt'
                if os.path.exists(thread_file_path):
                    with open(thread_file_path, 'r', encoding='utf-8') as f:
                        thread_id = f.read().strip()
                else:
                    return await reply.edit_text('Пожалуйста, сначала загрузите документ!')

                curr_doc_path = f'{dir_path}current_doc_id.txt'
                if os.path.exists(curr_doc_path):
                    with open(curr_doc_path, 'r', encoding='utf-8') as f:
                        doc_id = f.read().strip()
                else:
                    return await reply.edit_text('Пожалуйста, сначала загрузите документ!')

        elif msg.voice:
            reply = await msg.answer('Думаю...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))

            thread_file_path = f'users/{msg.from_user.username}/lawyer_threads/doc_thread_id.txt'
            if os.path.exists(thread_file_path):
                with open(thread_file_path, 'r', encoding='utf-8') as f:
                    thread_id = f.read().strip()
            else:
                return await reply.edit_text('Пожалуйста, сначала загрузите документ!')

            # читаем текущий doc_id
            curr_doc_path = f'{dir_path}current_doc_id.txt'
            if os.path.exists(curr_doc_path):
                with open(curr_doc_path, 'r', encoding='utf-8') as f:
                    doc_id = f.read().strip()
            else:
                return await reply.edit_text('Пожалуйста, сначала загрузите документ!')
        else:
            return await msg.answer('Не понял вас. Пожалуйста, перефразируйте запрос.')

        if new_thread:
            pass
        else:
            thread_file_path = f'users/{msg.from_user.username}/lawyer_threads/doc_thread_id.txt'
            with open(thread_file_path, 'r', encoding='utf-8') as f:
                thread_id = f.read().strip()

        openai_client.beta.threads.messages.create(
            thread_id=thread_id,
            role="user",
            content=f'{user_message}\nВот полный текст документа: {open(dir_path + 'current_doc_text.txt', mode='r', encoding='utf-8').read()}')

        run = openai_client.beta.threads.runs.create(thread_id=thread_id, assistant_id=LAWYER_ID)
        while run.status in ("queued", "in_progress"):
            time.sleep(0.5)
            run = openai_client.beta.threads.runs.retrieve(thread_id=thread_id, run_id=run.id)

        messages = openai_client.beta.threads.messages.list(thread_id=thread_id, order="asc")
        response = messages.data[-1].content[0].text.value

        return await reply.edit_text(re.sub(r'【.*?】', '', response), reply_markup=lawyer_docs_get_to_consulting())

    except Exception as e:
        return await msg.answer(f'Ошибка в работе с документами: {e}. Попробуйте еще раз.')

@router.message(LawyerAssistant.lawyer_consulting)
async def lawyer_consulting(msg: Message, state: FSMContext):
    try:
        user_message = None

        if msg.text:
            if await try_mode_switch(msg, state):
                return
            reply = await msg.answer('Думаю...')
            user_message = restricted_symbols(msg.text.replace('\n', ''))
        elif msg.voice:
            reply = await msg.answer('Думаю...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))
        else:
            await msg.answer(
                "❌ Я работаю только с Вашими сообщениями, не с документами.\n"
                "Пожалуйста, отправьте текст или голосовое сообщение."
            )
            return

        if user_message is None:
            await msg.answer("Ошибка при консультировании: Ошибка обработки сообщения. Попробуйте снова.")
            return

        thread_path = f'users/{msg.from_user.username}/lawyer_threads/consulting_thread_id.txt'
        os.makedirs(os.path.dirname(thread_path), exist_ok=True)

        try:
            with open(thread_path, 'r', encoding='utf-8') as thread_file:
                thread_id = thread_file.read().strip()
        except FileNotFoundError:
            thread_id = ""
        
        if not thread_id:
            thread_id = openai_client.beta.threads.create().id
            with open(thread_path, 'w', encoding='utf-8') as thread_file:
                thread_file.write(thread_id)

        openai_client.beta.threads.messages.create(thread_id=thread_id, role="user", content=user_message)
        run = openai_client.beta.threads.runs.create(thread_id=thread_id, assistant_id=LAWYER_ID)
        while run.status in ("queued", "in_progress"):
            time.sleep(0.5)
            run = openai_client.beta.threads.runs.retrieve(thread_id=thread_id, run_id=run.id)

        messages = openai_client.beta.threads.messages.list(thread_id=thread_id, order="asc", after="NOT_GIVEN")
        response = messages.data[-1].content[0].text.value
        response = md2tgmd.escape(response)
        return await reply.edit_text(re.sub(r'【.*?】', '', response), parse_mode='MarkdownV2', reply_markup=lawyer_consulting_get_to_docs())
    except Exception as e:
        return await msg.answer(f'Ошибка при консультировании: {e}. Попробуйте еще раз.')

@router.message(ContactCardInput.card_step_1)
async def card_input_1(msg: Message, state: FSMContext):
    try:
        if msg.photo is not None:
            largest_photo = msg.photo[-1] if msg.photo else None
            reply = await msg.answer('Сохраняю и распознаю изображение...')
            dir_path = 'buff_card_photos/'
            photo_file_id = largest_photo.file_id
            await msg.bot.download(file=largest_photo.file_id,
                                   destination=dir_path + '%s.jpg' % photo_file_id
                                   )
            img_path = '{}{}.jpg'.format(dir_path, photo_file_id)
            with open(img_path, 'rb') as photo:
                base64_img = base64.b64encode(photo.read()).decode('utf-8')
                photo.close()
            os.remove(img_path)
            recognition = openai_client.chat.completions.create(
                model='gpt-4o',
                messages=[
                    {
                        'role': 'developer',
                        'content': 'Тебе поступит фотография визитной карточки. Извлеки из фотографии текст на карточке.'
                    },
                    {
                        'role': 'user',
                        'content': [
                            {'type': 'text', 'text': msg.caption or ''},
                            {
                                'type': 'image_url',
                                'image_url': {
                                    'url': f'data:image/jpeg;base64,{base64_img}'
                                }
                            }
                        ]
                    }
                ]
            )
            card_text = recognition.choices[0].message.content
            await state.update_data(card_pic1=card_text)
            await state.set_state(ContactCardInput.card_step_2)
            await reply.edit_text('Первое фото загружено. Пожалуйста, отправьте мне второе (обратную сторону карты) при наличии. Если её нет, то нажмите кнопку "Нет оборота"', reply_markup=no_second_card_photo())
        elif msg.text and not msg.voice and not msg.document:
            reply = await msg.answer('Обрабатываю текстовую визитку...')
            card_text = msg.text
            await state.update_data(card_pic1=card_text)
            await state.set_state(ContactCardInput.card_step_2)
            await reply.edit_text('Текст визитки принят. Хотите добавить комментарий?', reply_markup=card_get_comment())
            
        else:
            if await try_mode_switch(msg, state):
                return
            else:
                return await msg.answer('Пожалуйста, отправьте фото визитки или введите контактные данные текстом.')

    except Exception as e:
        return await msg.answer(f'Ошибка в обработке визитки: {e}. Попробуйте еще раз.')

@router.callback_query(ContactCardInput.card_step_2, F.data == 'no_card_side_2')
async def no_card_side_2(callback: CallbackQuery, state: FSMContext):
    return await callback.message.edit_text('Хорошо. Хотите добавить комментарий?', reply_markup=card_get_comment())

@router.callback_query(ContactCardInput.card_step_2, F.data == 'card_comment_no')
async def no_card_comment(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text('Понял, загружаю данные в таблицу...')
    try:
        card_data = await state.get_data()
        card_data_str = '\n'.join(str(value) for value in card_data.values())
        current_date = callback.message.date.date().isoformat()

        card_data_prompt = f'''Ты ИИ-ассистент агентства НейроРешение. Извлеки данные с визитки клиента в JSON-объект по шаблону:
{{
    "date": "{current_date}",
    "name": "ФИО",
    "organization": "организация",
    "address": "адрес",
    "phones": "номера телефонов",
    "email": "email"
}}

Правила:
- Ответ только в виде JSON-объекта, без пояснений
- Дублирующиеся данные указывай 1 раз
- Пропущенные поля заменяй на ""
- Игнорируй данные ComBox Technology
- Телефоны возвращай в одну строку, разделяя их запятой'''

        response_json, _in, _out = llm.ask_json(card_data_str, None, card_data_prompt)

        # Обработка предупреждений от модели
        if not response_json or 'Warning' in json.dumps(response_json):
            await callback.message.edit_text(
                'Возникла ошибка при преобразовании текста в данные. Пожалуйста, попробуйте загрузить фотографию снова.')
            return await state.set_state(ContactCardInput.card_step_1)

        # Преобразование JSON в список для append_card_data
        card_data_final = [
            response_json.get('date', ''),
            response_json.get('name', ''),
            response_json.get('organization', ''),
            response_json.get('address', ''),
            response_json.get('phones', ''),
            response_json.get('email', '')
        ]

        # Добавление данных в таблицу
        append_card_data(GOOGLE_SHEET_CONTACTS_ID, card_data_final, 'Потенциальные клиенты')

        # Формирование ответа пользователю
        success_text = 'Данные с визитки успешно добавлены в таблицу!\n\nВот добавленные данные:'
        col_list = [
            'Дата добавления', 'Имя клиента', 'Организация',
            'Локация', 'Телефон(ы)', 'Электронная почта'
        ]

        for value, column in zip(card_data_final, col_list):
            success_text += f'\n{column}: {value if value else "НЕ УКАЗАНО"}'

        await state.clear()
        await state.set_state(ContactCardInput.card_step_1)

        await callback.message.edit_text(
            f'{success_text}\n\nЕсли хотите, можете добавить ещё одну визитку. '
            'Если нет, то вы можете выйти из режима визиток, переключив режим по кнопке.'
        )

    except Exception as e:
        await callback.message.edit_text(f'Ошибка при распознавании визитки: {e}. Попробуйте еще раз.')

@router.callback_query(ContactCardInput.card_step_2, F.data == 'card_comment_yes')
async def card_comment_yes(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ContactCardInput.get_comments)
    return await callback.message.edit_text('Хорошо. Добавьте комментарий, я внесу его в таблицу.')

@router.message(ContactCardInput.card_step_2)
async def card_input_2(msg: Message, state: FSMContext):
    try:
        if not msg.voice and not msg.document and not msg.photo:
            if await try_mode_switch(msg, state):
                return
            else:
                return await msg.answer('Пожалуйста, отправьте второе фото визитки.')
        elif msg.photo is not None:
            largest_photo = msg.photo[-1] if msg.photo else None
            reply = await msg.answer('Сохраняю и распознаю изображение...')
            dir_path = 'buff_card_photos/'
            photo_file_id = largest_photo.file_id
            await msg.bot.download(file=largest_photo.file_id,
                                   destination=dir_path + '%s.jpg' % photo_file_id
                                   )
            img_path = '{}{}.jpg'.format(dir_path, photo_file_id)
            with open(img_path, 'rb') as photo:
                base64_img = base64.b64encode(photo.read()).decode('utf-8')
                photo.close()
            os.remove(img_path)
            recognition = openai_client.chat.completions.create(
                model='gpt-4o',
                messages=[
                    {
                        'role': 'developer',
                        'content': 'Тебе поступит фотография визитной карточки. Извлеки из фотографии текст на карточке.'

                    },
                    {
                        'role': 'user',
                        'content': [
                            {'type': 'text', 'text': msg.caption or ''},
                            {
                                'type': 'image_url',
                                'image_url': {
                                    'url': f'data:image/jpeg;base64,{base64_img}'
                                }
                            }
                        ]
                    }
                ]
            )
            card_text = recognition
            await state.update_data(card_pic1=card_text)
            return await reply.edit_text(f'Спасибо за фото. Хотите добавить комментарий?', reply_markup=card_get_comment())
    except Exception as e:
        return await msg.answer(f'Ошибка при обработке обратной стороны визитки: {e}. Попробуйте еще раз.')

@router.message(ContactCardInput.get_comments)
async def get_comments(msg: Message, state: FSMContext):
    try:
        # Обработка разных типов сообщений
        if not msg.voice and not msg.document and not msg.photo:
            reply = await msg.answer('Думаю...')
            user_message = msg.text
            user_message = restricted_symbols(user_message.replace('\n', ''))
        elif msg.voice is not None:
            reply = await msg.answer('Думаю...')
            message = await transcribe_voice(msg.voice.file_id, msg.bot)
            user_message = restricted_symbols(message.replace('\n', ''))
        else:
            return await msg.answer('Ошибка при формировании комментария. Попробуйте еще раз.')

        # Сбор данных из состояния
        card_data = await state.get_data()
        card_data_str = '\n'.join(str(value) for value in card_data.values())
        data_with_comments = f'{card_data_str} {user_message}'
        current_date = msg.date.date().isoformat()

        # Подготовка JSON-структуры для ответа
        json_structure = {
            "date": current_date,
            "name": "ФИО",
            "organization": "организация",
            "address": "адрес",
            "phones": "номера телефонов",
            "email": "email",
            "telegram": "телеграм",
            "communication_channel": "канал связи",
            "socials": "соцсети/проекты",
            "client_request": "запрос клиента",
            "interaction_stages": "этапы взаимодействия",
            "client_response": "ответ клиента",
            "agency_response": "ответ агентства",
            "needs": "потребности",
            "status": "статус",
            "next_steps": "дальнейшие действия",
            "note": "заметка",
            "last_contact_date": "дата последнего контакта"
        }

        # Формирование промпта для LLM
        card_data_prompt = f'''Ты ИИ-ассистент агентства НейроРешение. Извлеки данные с визитки клиента и комментариев сотрудника агентства в JSON-объект по шаблону:
{json.dumps(json_structure, ensure_ascii=False, indent=2)}

Правила:
- Ответ только в виде JSON-объекта, без пояснений
- Дублирующиеся данные указывай 1 раз
- Пропущенные поля заменяй на ""
- Игнорируй данные ComBox Technology
- Особое внимание уделите полям: канал связи, соцсети/проекты, запрос клиента, этапы взаимодействия, потребности, статус, заметка
- Телефоны возвращай в одну строку через запятую'''

        response_json, _in, _out = llm.ask_json(data_with_comments, None, card_data_prompt)

        # Проверка предупреждений от модели
        if not response_json or 'Warning' in json.dumps(response_json):
            await reply.edit_text(
                'Возникла ошибка при преобразовании текста в данные. Пожалуйста, попробуйте загрузить фотографию снова.')
            return await state.set_state(ContactCardInput.card_step_1)

        # Преобразование JSON в список для append_card_data
        card_data_final = [
            response_json.get('date', ''),
            response_json.get('name', ''),
            response_json.get('organization', ''),
            response_json.get('address', ''),
            response_json.get('phones', ''),
            response_json.get('email', ''),
            response_json.get('telegram', ''),
            response_json.get('communication_channel', ''),
            response_json.get('socials', ''),
            response_json.get('client_request', ''),
            response_json.get('interaction_stages', ''),
            response_json.get('client_response', ''),
            response_json.get('agency_response', ''),
            response_json.get('needs', ''),
            response_json.get('status', ''),
            response_json.get('next_steps', ''),
            response_json.get('note', ''),
            response_json.get('last_contact_date', '')
        ]

        # Добавление данных в таблицу
        append_card_data(GOOGLE_SHEET_CONTACTS_ID, card_data_final, 'Потенциальные клиенты')

        # Формирование ответа пользователю
        success_text = 'Данные с визитки успешно добавлены в таблицу!\n\nВот добавленные данные:'
        col_list = [
            'Дата добавления', 'Имя клиента', 'Организация', 'Локация', 'Телефон(ы)', 'Электронная почта',
            'Никнейм в Телеграме', 'Предпочит. канал связи', 'Соцсети и проекты', 'Запрос клиента',
            'Этапы взаимодействия', 'Ответ клиента', 'Ответ агентства', 'Ключевые потребности клиента',
            'Статус взаимодействия', 'Дальнейшие действия', 'Персональная заметка', 'Дата последнего контакта'
        ]

        for value, column in zip(card_data_final, col_list):
            success_text += f'\n{column}: {value if value else "НЕ УКАЗАНО"}'

        await state.clear()
        await state.set_state(ContactCardInput.card_step_1)

        await reply.edit_text(
            f'{success_text}\n\nЕсли хотите, можете добавить ещё одну визитку. '
            'Если нет, то можете выйти из режима визиток, переключив режим по кнопке.'
        )

    except Exception as e:
        await msg.answer(f'Ошибка при сохранении визитки: {e}. Попробуйте еще раз.')
