import os
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from states.states import Notes
from keyboards.reply_keyboards import main_kb
router = Router()

@router.message(CommandStart())
async def start_handler(msg: Message, state: FSMContext):
    try:
        greeting_message = open('texts_and_prompts/greetings.txt', mode='r', encoding='utf-8').read()
        user_dirs = ['saved_notes', 'llm_context', 'lawyer_threads', 'lawyer_sdocs']
        user_file_dirs = ['saved_notes', 'llm_context', 'lawyer_threads', 'lawyer_threads', 'lawyer_sdocs', 'lawyer_sdocs']
        user_files = ['notes.txt', 'context.txt', 'doc_thread_id.txt', 'consulting_thread_id.txt', 'current_doc_id.txt', 'current_doc_text.txt']
        username = msg.from_user.username
        for dir in user_dirs:
            dir_path = 'users/' + username + '/' + '' + dir
            if not os.path.exists(dir_path):
                os.makedirs(dir_path)
        for dir, file in zip(user_file_dirs, user_files):
            try:
                file_path = 'users/' + username + '/' + dir + '/' + file
                if not os.path.isfile(file_path):
                    with open(file_path, mode='x', encoding='utf-8') as user_file:
                        user_file.close()
            except FileExistsError:
                pass
        if open(f'users/{username}/llm_context/context.txt', mode='r', encoding='utf-8').read() == '':
            start_context = open(f'users/{username}/llm_context/context.txt', mode='w', encoding='utf-8')
            start_context.write(f'Привет!%%%{greeting_message.replace("\n", " ")}')
            start_context.close()

        await msg.answer(greeting_message, reply_markup=main_kb())
        await state.set_state(Notes.notes)
    except Exception as e:
        print(f"Ошибка: {str(e)}")
        await msg.answer('Что-то пошло не так. Пожалуйста, убедитесь, что у вас есть никнейм в Телеграме. Если его нет - создайте его и снова нажмите /start')