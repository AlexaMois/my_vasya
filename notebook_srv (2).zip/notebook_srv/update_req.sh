﻿#!/usr/bin/env bash
set -euo pipefail

# ---------- helpers ----------
print()  { echo -e "$*"; }
error()  { print "\033[1;31m❌ $*\033[0m"; }
info()   { print "\033[1;34m🔨 $*\033[0m"; }
ok()     { print "\033[1;32m✅ $*\033[0m"; }
warn()   { print "\033[1;33m⚠️  $*\033[0m"; }

# ---------- main ----------
clear
info "Обновление виртуального окружения .venv\n"

# 1. Проверяем, существует ли .venv
if [[ ! -d .venv ]]; then
    error "Папка .venv не найдена. Сначала создайте окружение."
    exit 1
fi

# 2. Активируем venv и обновляем pip
info "Активирую .venv и обновляю pip…"
source .venv/bin/activate
python3.12 -m pip install --quiet --upgrade pip

# 3. Устанавливаем/обновляем зависимости
if [[ -f requirements.txt ]]; then
    info "Устанавливаю/обновляю зависимости из requirements.txt…"
    pip install --quiet -r requirements.txt
else
    warn "Файл requirements.txt не обнаружен – ничего не ставлю."
fi

print ""
ok "Виртуальное окружение обновлено!"
print "Активируйте его при необходимости:  source .venv/bin/activate"